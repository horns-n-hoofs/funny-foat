$(document).ready(function() {			
	$("a.gallery").fancybox();			
});