$(document).ready(function() {
	if(window.screen.width > 960) {

	    document.write('<script src="js/menu.js"></script>');
		
	}
  });